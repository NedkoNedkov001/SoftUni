﻿namespace Warehouse.Core.Models
{
    public class UserRolesViewModel
    {
        public string UserId { get; set; }

        public string Name { get; set; }

        public string[] RoleNames { get; set; }
    }
}
