﻿namespace Warehouse.Core.Constants
{
    public static class UserConstants
    {
        public static class Roles
        {
            public const string Administrator = "Administrator";

            public const string Manager = "Administrator, Manager";
        }
    }
}
