﻿
using Warehouse.Infrastructure.Data.Common;

namespace Warehouse.Infrastructure.Data.Repositories
{
    public interface IApplicatioDbRepository : IRepository
    {
    }
}
