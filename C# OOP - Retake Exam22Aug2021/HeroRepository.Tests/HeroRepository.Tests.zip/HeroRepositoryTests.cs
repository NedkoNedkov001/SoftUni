using System;
using NUnit.Framework;

[TestFixture]
public class HeroRepositoryTests
{
    [Test]
    public void testCtor()
    {
        HeroRepository repository = new HeroRepository();
        Assert.AreEqual(repository.Heroes.Count, 0);
    }
    [Test]
    public void testCreateSuccessfully()
    {
        HeroRepository repository = new HeroRepository();
        Hero hero = new Hero("Pesho", 1);
        repository.Create(hero);
        Assert.AreEqual(repository.Heroes.Count, 1);
    }
    [Test]
    public void testCreateNull()
    {
        HeroRepository repository = new HeroRepository();
        Assert.Throws<ArgumentNullException>(() => repository.Create(null));
    }
    [Test]
    public void testCreateExisting()
    {
        HeroRepository repository = new HeroRepository();
        Hero hero = new Hero("Pesho", 1);
        Hero heroTwo = new Hero("Pesho", 1);
        repository.Create(hero);
        Assert.Throws<InvalidOperationException>(() => repository.Create(heroTwo));
    }
    [Test]
    public void testRemoveSuccessfully()
    {
        HeroRepository repository = new HeroRepository();
        Hero hero = new Hero("Pesho", 1);
        repository.Create(hero);
        Assert.AreEqual(repository.Heroes.Count, 1);
        repository.Remove("Pesho");
        Assert.AreEqual(repository.Heroes.Count, 0);
    }
    [Test]
    public void testRemoveNull()
    {
        HeroRepository repository = new HeroRepository();
        Hero hero = new Hero("Pesho", 1);
        repository.Create(hero);
        Assert.Throws<ArgumentNullException>(() => repository.Remove(null));
    }
    [Test]
    public void testGetHeroWithHighestLevel()
    {
        HeroRepository repository = new HeroRepository();
        Hero hero = new Hero("Pesho", 5);
        Hero heroLowLvl = new Hero("PeshoLow", 1);
        Hero heroHighLvl = new Hero("PeshoHigh", 10);
        repository.Create(hero);
        repository.Create(heroLowLvl);
        repository.Create(heroHighLvl);
        Assert.AreEqual(repository.GetHeroWithHighestLevel(), heroHighLvl);
    }
    [Test]
    public void testGetHero()
    {
        HeroRepository repository = new HeroRepository();
        Hero hero = new Hero("Pesho", 5);
        Hero heroLowLvl = new Hero("PeshoLow", 1);
        Hero heroHighLvl = new Hero("PeshoHigh", 10);
        repository.Create(hero);
        repository.Create(heroLowLvl);
        repository.Create(heroHighLvl);
        Assert.AreEqual(repository.GetHero("PeshoLow"), heroLowLvl);
    }
}