﻿using NUnit.Framework;

namespace Robots.Tests
{
    using System;

    public class RobotsTests
    {
        private RobotManager robotManager;

        [SetUp]
        public void SetUp()
        {
            robotManager = new RobotManager(5);
        }

        [Test]
        public void Robot()
        {
            Robot robot = new Robot("Dido", 22);

            Assert.That(robot.Name, Is.EqualTo("Dido"));
            Assert.That(robot.MaximumBattery, Is.EqualTo(22));
        }
        [Test]
        public void TestingTheCtor()
        {
            RobotManager robotManager = new RobotManager(5);

            Assert.That(robotManager.Capacity, Is.EqualTo(5));
        }

        [Test]
        public void InvalidCapacity()
        {
            Assert.Throws<ArgumentException>(()=>robotManager = new RobotManager(-2));
        }

        [Test]
        public void AddARobot()
        {
            robotManager.Add(new Robot("Gosho", 50));

            Assert.That(robotManager.Count, Is.EqualTo(1));
        }

        [Test]
        public void AddingAnExistingRobotThrowsAnExc()
        {
            robotManager.Add(new Robot("Gosho", 50));
            Assert.Throws<InvalidOperationException>(()=> robotManager.Add(new Robot("Gosho", 50)));

        }

        [Test]
        public void AddingRobotsOverTheCap()
        {
            robotManager.Add(new Robot("Gosho", 50));
            robotManager.Add(new Robot("Pesho", 50));
            robotManager.Add(new Robot("Dancho", 50));
            robotManager.Add(new Robot("Rado", 50));
            robotManager.Add(new Robot("Valio", 50));

            Assert.Throws<InvalidOperationException>(() => robotManager.Add(new Robot("Hari", 50)));
        }

        [Test]
        public void RemovingARobot()
        {
            robotManager.Add(new Robot("Gosho", 50));
            robotManager.Add(new Robot("Pesho", 50));
            robotManager.Add(new Robot("Dancho", 50));

            robotManager.Remove("Gosho");

            Assert.That(robotManager.Count, Is.EqualTo(2));
        }

        [Test]
        public void RemovingInexistantRobot()
        {
            robotManager.Add(new Robot("Gosho", 50));

            Assert.Throws<InvalidOperationException>(() => robotManager.Remove("Pepo"));
        }

        [Test]
        public void WorkingWithNullRobot()
        {
            robotManager.Add(new Robot("Gosho", 50));

            Assert.Throws<InvalidOperationException>(() => robotManager.Work("Dido", "Chistach", 22));
        }

        [Test]
        public void WorkingWithNotEnoughEnergy()
        {
            robotManager.Add(new Robot("Gosho", 50));

            Assert.Throws<InvalidOperationException>(() => robotManager.Work("Gosho", "Chistach", 60));

        }

        [Test]
        public void ChargingWithNullRobot()
        {
            robotManager.Add(new Robot("Gosho", 50));

            Assert.Throws<InvalidOperationException>(()=> robotManager.Charge("Pepo"));
        }

        [Test]
        public void Workin()
        {
            Robot robot = new Robot("Gosho", 50);

            robotManager.Add(robot);
            robotManager.Work("Gosho", "tarikat", 25);

            Assert.That(robot.Battery, Is.EqualTo(25));
        }

        [Test]
        public void Charging()
        {
            Robot robot = new Robot("Gosho", 50);

            robotManager.Add(robot);
            robotManager.Work("Gosho", "tarikat", 25);

            robotManager.Charge("Gosho");
            Assert.That(robot.Battery, Is.EqualTo(robot.MaximumBattery));
        }
    }
}
